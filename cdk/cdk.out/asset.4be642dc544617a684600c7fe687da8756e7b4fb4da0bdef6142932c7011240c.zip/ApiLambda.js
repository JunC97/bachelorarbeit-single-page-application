const AWS = require('aws-sdk');
const RDS = new AWS.RDSDataService();
const s3 = new AWS.S3();

var styleResponse = require('./styleResponse');
var statementCreator = require('./createStatements');

exports.handler = async (event, context) => {
    const parsed_event = JSON.parse(JSON.stringify(event));
    const path = await parsed_event["path"];
    const eventRows = await parsed_event["rows"];
    const eventValues = await parsed_event["values"];
    var eventCondition = "";
    eventCondition = await parsed_event["condition"];
    const sliced_path = await path.slice(1);
    const split_path = await sliced_path.split('/');
    console.log("extracted path: " + path);
    //console.log("extracted path split: " + sliced_path);
    console.log("extracted path split: " + split_path);

    var sqlStatement = '';
    var rows = "";
    var values = "";
    var update = "";

    if (eventRows.length > 1) {
         for(var i = 0; i < eventRows.length; i++){
             if(i == eventRows.length-1){
                 rows = rows + eventRows[i];
                 values = values + "'" + eventValues[i] + "'";
                 break;
             }
             rows = rows + eventRows[i] + ", ";
             values = values + "'" + eventValues[i] + "', ";
         }
     }else {
         console.log("ERROR IN STATEMENT CREATION");
     }

     if(split_path[split_path.length-1] == 'update'){
        if (eventRows.length > 1) {
            for(var i = 0; i < eventRows.length; i++){
                if(i == eventRows.length-1){
                    update = update + eventRows[i] + " = '" + eventValues[i] + "'";
                    break;
                }
                update = update + eventRows[i] + " = '" + eventValues[i] + "', ";
            }
            update = update + " WHERE " + eventCondition;
        }else {
            console.log("ERROR IN UPDATE STATEMENT CREATION");
        }
    }
    console.log("rows: " + rows + " values: " + values);

    //IMPLEMENT WAY TO DISTINGUISH (JOINED) TABLES
    //SET TABLES THEN WRITE QUERIES SPECIFICLY AS NEEDED

    try {

        /*##############################*\
        |#      CREATE STATEMENTS       #|
        \*##############################*/
        //required parameters:
        //rows, values, update, split_path, eventCondition, sqlStatement
        sqlStatement = statementCreator.createStatements(rows, values, update, split_path, eventCondition, sqlStatement);

    } catch (e) {
        console.log("ERROR WHILE CREATING STATEMENTS!")
    }

    try {
        /*######################*\
        |#      EXECUTION       #|
        \*######################*/
        const params = {
            secretArn: process.env.serverlessClusterSecretArn,
            resourceArn: process.env.dbClusterArn,
            sql: sqlStatement,
            database: 'auroraDbVwDpp',
        }
        console.log("SQL-Statement to be executed: " + sqlStatement)
        let dbRespo = await RDS.executeStatement(params).promise();
        (!dbRespo) ? console.log("execution failed!") : console.log("execution successfull!");

        //----------------------------------------------------------------------

        /*######################*\
        |#      RESPONSE        #|
        \*######################*/

        //ONLY SEND DATA IN BODY WHEN SELECT QUERY WAS EXECUTED
        if(split_path[split_path.length-1] == 'find'){
            var obj = styleResponse.createStructure(split_path, dbRespo);
            const response = {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin" : "*",
                    "Access-Control-Allow-Credentials" : true
                },
                body: JSON.stringify(obj, null, 2),
            };
            console.log("SUCCESS! Following query was successfully sent and executed: " + sqlStatement + ". Called API: " + path)
            return response

        } else {
            const response = {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Credentials" : true
            },
            body: "SUCCESS! Following query was successfully sent and executed: " + sqlStatement + ". Called API: " + path,
            };
            return response
        }


    } catch (err) {
        console.log(err)
        return err
    }
};
