const AWS = require('aws-sdk');
const RDS = new AWS.RDSDataService();

var statementCreator = require('./statementCreator');
var styleResponse = require('./styleResponse');

exports.handler = async (event, context) => {
    const parsed_event = JSON.parse(JSON.stringify(event));
    const path = await parsed_event["path"];
    var title = "";
    var notes = "";
    try{
        title = await parsed_event["queryStringParameters"]["title"];
        notes = await parsed_event["queryStringParameters"]["notes"];
        console.log("Title: " + title + " | Notes: " + notes);
    }catch(err){
        
    }
    
    var eventCondition = "";
    eventCondition = await parsed_event["condition"];
    const sliced_path = await path.slice(1);
    const split_path = await sliced_path.split('/');
    console.log("extracted path: " + path);
    //console.log("extracted path split: " + sliced_path);
    console.log("extracted path split: " + split_path);

    var sqlStatement = '';
    

    //IMPLEMENT WAY TO DISTINGUISH (JOINED) TABLES
    //SET TABLES THEN WRITE QUERIES SPECIFICLY AS NEEDED

    try {

        /*##############################*\
        |#      CREATE STATEMENTS       #|
        \*##############################*/
        //required parameters:
        sqlStatement = await statementCreator.createStatements(split_path, title, notes);

    } catch (e) {
        console.log("ERROR WHILE CREATING STATEMENTS!")
    }

    try {
        /*######################*\
        |#      EXECUTION       #|
        \*######################*/
        console.log("TYPE OF: " +  typeof sqlStatement)
        console.log("CONTENT: " +  JSON.stringify(sqlStatement,2,null))
        const params = {
            secretArn: "arn:aws:secretsmanager:eu-west-1:500697513029:secret:DatabaseStackDatabaaseClust-UCAdL0hMkUuj-bbyD8e",
            resourceArn: "arn:aws:rds:eu-west-1:500697513029:cluster:bachelorarbeit-database-databaaseclusterserverle-39sewxru76g4",
            sql: sqlStatement,
            database: 'bachelorarbeit_aurora_serverless_database',
        }
        console.log("SQL-Statement to be executed: " + sqlStatement)
        let dbRespo = await RDS.executeStatement(params).promise();
        (!dbRespo) ? console.log("execution failed!") : console.log("execution successfull!");

        //----------------------------------------------------------------------

        /*######################*\
        |#      RESPONSE        #|
        \*######################*/

        //ONLY SEND DATA IN BODY WHEN SELECT QUERY WAS EXECUTED
        if(split_path[split_path.length-1] == 'find'){
            console.log("DBRESPO: " + JSON.stringify(dbRespo,2,null))
            var obj = styleResponse.styleFindAllNotesResponse(split_path, dbRespo);
            const response = {
                statusCode: 200,
                headers: {
                    "Access-Control-Allow-Origin" : "*",
                    "Access-Control-Allow-Credentials" : true
                },
                body: JSON.stringify(obj, null, 2),
            };
            console.log("SUCCESS! Following query was successfully sent and executed: " + sqlStatement + ". Called API: " + path)
            return response

        } else {
            const response = {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin" : "*",
                "Access-Control-Allow-Credentials" : true
            },
            body: "SUCCESS! Following query was successfully sent and executed: " + sqlStatement + ". Called API: " + path,
            };
            return response
        }


    } catch (err) {
        console.log(err)
        return err
    }
};
