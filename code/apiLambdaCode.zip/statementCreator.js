module.exports = {
  createStatements: async function (split_path, title, notes) {
    //console.log("-----------------" + split_path[split_path.length-1]);
    var sql = '';
    switch (split_path[split_path.length-1]) {
            case 'create':
                sql = "insert into notes (title, notes, date) values ('" + title + "','" + notes + "', current_timestamp);";
                break;
            case 'find':
              sql = "select * from notes;";
              break;
        }
        return sql;
  }
};