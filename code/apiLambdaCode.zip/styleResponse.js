module.exports = {
  styleFindAllNotesResponse: function (split_path, dbRespo) {
    var root = {
      "id": 0,
      "name": "root",
      "typ": "root",
      "notes": []
    };

    //go through all projects
      for(var i = 0; i < dbRespo["records"].length; i++){
        //get needed values
        if(dbRespo["records"][i][0] == undefined){
        break;
        }
        var note = {};
        //insert all project ids + required field into obj
        note = {
            "id": dbRespo["records"][i][0]["longValue"],
            "title": dbRespo["records"][i][1]["stringValue"],
            "note": dbRespo["records"][i][2]["stringValue"],
            "date": dbRespo["records"][i][3]["stringValue"],
            "typ": "note"
        };
        root["notes"].push(note);
        note = {};
        }

    return root;
  },
};